const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const Book = require('../models/Book');
const User = require('../models/User');
// Promote user to admin (for setup/testing only)
router.post('/make-admin', async (req, res) => {
    const { email } = req.body;
    if (!email) return res.status(400).json({ msg: 'Email required.' });
    try {
        const user = await User.findOneAndUpdate({ email }, { $set: { isAdmin: true } }, { new: true });
        if (!user) return res.status(404).json({ msg: 'User not found.' });
        res.json({ msg: 'User promoted to admin.', user });
    } catch (err) {
        res.status(500).json({ msg: 'Server error.' });
    }
});

// Storage config for book files and cover images
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        if (file.fieldname === 'bookFile') {
            cb(null, path.join(__dirname, '../../uploads/books'));
        } else if (file.fieldname === 'coverImage') {
            cb(null, path.join(__dirname, '../../uploads/covers'));
        }
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + '-' + file.originalname);
    }
});
const upload = multer({ storage });

// Admin-only upload route
router.post('/upload', upload.fields([
    { name: 'bookFile', maxCount: 1 },
    { name: 'coverImage', maxCount: 1 }
]), async (req, res) => {
    try {
        // No admin check, any logged-in user can upload
        const { title, author, category, description, price } = req.body;
        const bookFile = req.files['bookFile'] ? req.files['bookFile'][0].filename : null;
        const coverImage = req.files['coverImage'] ? req.files['coverImage'][0].filename : null;

        if (!bookFile) return res.status(400).json({ msg: 'Book file required.' });

        const newBook = new Book({
            title,
            author,
            category,
            description,
            price: price || 0,
            isPaid: price > 0,
            filePath: `/uploads/books/${bookFile}`,
            coverImage: coverImage ? `/uploads/covers/${coverImage}` : undefined
        });
        await newBook.save();
        res.status(201).json(newBook);
    } catch (err) {
        console.error(err);
        res.status(500).json({ msg: 'Server error uploading book.' });
    }
});

module.exports = router;
