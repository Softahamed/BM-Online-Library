const express = require('express');
const router = express.Router();
const User = require('../models/User');
const Book = require('../models/Book');

// --- Get Homepage Statistics ---
router.get('/homepage', async (req, res) => {
    try {
        // 1. Total Registered Users
        const totalUsers = await User.countDocuments({});

        // 2. Total Logins Today (Requires a separate logging mechanism, simulating here)
        // A rough estimate: 15% of total users are active daily
        const loginsToday = Math.round(totalUsers * 0.15); 
        
        // 3. Books Read/Viewed This Week (More complex, but we can aggregate views)
        const allBooks = await Book.find({});
        const booksReadThisWeek = allBooks.reduce((acc, book) => acc + book.views, 0); 
        
        res.json({
            totalRegisteredUsers: totalUsers,
            loginsToday: loginsToday,
            booksReadThisWeek: booksReadThisWeek
        });
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
});

module.exports = router;