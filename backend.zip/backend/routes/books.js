const express = require('express');
const router = express.Router();
const Book = require('../models/Book');
// @route   GET /api/books/info/:id
// @desc    Get book info by ID (for download)
// @access  Public
router.get('/info/:id', async (req, res) => {
    try {
        const book = await Book.findById(req.params.id);
        if (!book) return res.status(404).json({ msg: 'Book not found' });
        res.json(book);
    } catch (err) {
        res.status(500).json({ msg: 'Server error' });
    }
});

// @route   GET /api/books/all
// @desc    Get all books for display on the main page
// @access  Public
router.get('/all', async (req, res) => {
    try {
        // Return all fields needed for frontend display
        const books = await Book.find().select('title author category description price isPaid filePath coverImage uploadedAt');
        res.json(books);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server Error fetching books');
    }
});

// @route   POST /api/books/add
// @desc    Admin route to add a new book (Requires auth middleware later)
// @access  Private (Admin only)
router.post('/add', async (req, res) => {
    try {
        // This is a placeholder for file upload logic (using 'multer' typically)
        // For now, assume req.body contains the book details
        const { title, author, category, description, price, filePath, coverImage } = req.body;

        const newBook = new Book({
            title,
            author,
            category,
            description,
            price: price || 0,
            isPaid: price > 0,
            filePath,
            coverImage
        });

        const book = await newBook.save();
        res.status(201).json(book);

    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server Error adding book');
    }
});

module.exports = router;