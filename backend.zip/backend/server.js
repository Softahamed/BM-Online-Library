const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const cors = require('cors'); // To allow cross-origin requests from your frontend

// Import Routes
const authRoutes = require('./routes/auth');
const bookRoutes = require('./routes/books');
const statsRoutes = require('./routes/stats');
const paymentRoutes = require('./routes/payment'); 

dotenv.config(); // Load environment variables (like MongoDB URI)

const app = express();
const PORT = process.env.PORT || 5000;
const MONGODB_URI = process.env.MONGODB_URI;

// --- Middlewares ---
app.use(cors()); // Allow your frontend (e.g., http://localhost:3000) to talk to the backend
app.use(express.json()); // Body parser for JSON requests
app.use(express.static(__dirname + '/../'));

// --- Database Connection ---
mongoose.connect(MONGODB_URI)
    .then(() => console.log('MongoDB connection established successfully!'))
    .catch(err => console.error('MongoDB connection error:', err));

// --- API Routes ---
app.use('/api/auth', authRoutes); // /api/auth/register, /api/auth/login
app.use('/api/books', bookRoutes); // /api/books/all, /api/books/read/:id
app.use('/api/stats', statsRoutes); // /api/stats/homepage
app.use('/api/payment', paymentRoutes); // /api/payment/checkout
app.use('/api/admin', require('./routes/admin'));

// Serve uploaded files statically
app.use('/uploads', express.static('uploads'));

// --- Start Server ---
app.listen(PORT, () => {
    console.log(`BM Online Library Server running on port ${PORT}`);
});