// backend/models/Book.js

const mongoose = require('mongoose');

const BookSchema = new mongoose.Schema({
    title: { type: String, required: true, trim: true },
    author: { type: String, required: true, trim: true },
    category: { type: String, required: true }, // e.g., 'Fiction', 'Science', 'History'
    description: { type: String, required: true },
    price: { type: Number, default: 0 }, // 0 means Free
    isPaid: { type: Boolean, default: false },
    filePath: { type: String, required: true }, // Path to the PDF/ePub file
    coverImage: { type: String }, // Path to the cover image file
    views: { type: Number, default: 0 },
    uploadedAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Book', BookSchema);